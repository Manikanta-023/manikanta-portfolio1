# Manikanta Naik — Developer Portfolio

## Run it
1. Extract the ZIP file.
2. Open `index.html` in a browser, or open the folder in VS Code.
3. Optional: install the VS Code extension **Live Server**, right-click `index.html`, and choose **Open with Live Server**.

## Before publishing
- Replace `your.email@example.com` with your real email.
- Replace the GitHub and LinkedIn links with your profile URLs.
- Add your resume PDF link and project repository links.
- Confirm the skills and project descriptions reflect your actual experience.
- Add your own profile photo if you prefer (the current design uses the initials MN).

## Free hosting with GitHub Pages
1. Create a GitHub repository named `yourusername.github.io` (replace `yourusername` with your GitHub username).
2. Upload `index.html` to the repository root.
3. Open the repository's **Settings → Pages** and enable deployment from the `main` branch and `/ (root)` folder, if prompted.
4. Your site will be available at `https://yourusername.github.io` after deployment finishes.
